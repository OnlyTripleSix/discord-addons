# BetterDiscord Quick Mock and Hidden Channels

Version **1.0.0**. User-accepted desktop releases by **ItsTripleSix**.

## Install

1. Extract `BetterDiscord-Mock-HiddenChannels-1.0.0.zip`.
2. Open Discord Settings → BetterDiscord → Plugins → Open Plugins Folder.
3. Copy `QuickMock.plugin.js` and `HiddenChannels.plugin.js` into that folder, then enable both. Each plugin is independent; either one can be installed alone.

No custom Discord build or extra plugin library is required. Keep any existing configuration when updating.

## Quick Mock

- **Right-click a text message → Mock** inserts alternating-case text into the current channel's composer. Existing draft text is preserved. If the channel is not the active composer, the result is copied instead of navigating away.
- **`/mock message:I know everything`** sends `i KnOw eVeRyThInG` as a real message.
- **Reply to a text message, then `/mock`** uses the pending reply's text and retains Discord's native reply reference.
- The plugin settings option **Message-menu action sends immediately** is off by default. Turn it on only if you want a click on Mock to send immediately. Slash commands send when submitted, as usual.
- If a send fails, the result is returned to the composer or clipboard for review. It is not retried automatically.
- `/mock` uses BetterDiscord's Commands API. On older BetterDiscord versions, the message menu works and the settings explain that an update is needed for commands.

The transformation alternates ASCII letters only. Numbers, punctuation, spacing, emoji, and non-ASCII characters are retained.

## Hidden Channels

- Loaded inaccessible channels appear in the channel list with a lock marker. Collapsed categories stay collapsed.
- Clicking a locked row opens its cached name, type, category, topic, creation time, channel ID, and permission-rule count. It does not open message history or join voice.
- **Right-click a server → Hidden Channels** opens the full cached list for that server. The plugin settings provide the same server-list shortcut.
- Native server permissions remain unchanged. Locked history/message requests and voice/navigation actions are guarded, and hidden-channel unread/mention indicators are suppressed locally.
- Only metadata Discord already supplied can be shown. If the server withholds a channel or sanitizes its name, the plugin cannot reconstruct it. It does not grant channel/message access.
- Open a server if the channel list was not loaded yet. If the plugin reports missing Discord modules, include that error in the test report.

Disabling the plugin removes hooks, listeners, lock markers and styles, closes its windows, and restores native list display states.

## Validation

36 automated compiled-plugin integration checks and browser checks passed. The checks cover command sending/replies, review versus immediate send, existing drafts, account changes, menu cleanup, hidden/allowed message routes, native permission preservation, categories, metadata escaping, unread counts, mouse/keyboard routing, nested dialogs, disable/reenable, and narrow layouts.

All message sends and network responses in the automated checks are simulated. The user tested both desktop builds and reported them flawless, then authorized public release. Version 1.0.0 changes only the version label from the accepted beta 1 plugin files. This acceptance does not independently verify every permission, voice, reply, or recovery scenario.

## License

MIT License. Author: ItsTripleSix. Discord and BetterDiscord are independent projects; this collection is unaffiliated.
